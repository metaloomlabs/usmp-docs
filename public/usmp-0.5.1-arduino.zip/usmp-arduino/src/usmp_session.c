#include "usmp_session.h"

#include <stdio.h>
#include <string.h>

#include "usmp_api.h"
#include "usmp_crypto.h"
#include "usmp_frame.h"
#include "usmp_port.h"

static const char* TAG = "USMP_SESSION";

/*
 * Maximum number of consecutive control frames (PING/PONG) processed in a
 * single usmp_recv() call before giving up. Prevents infinite loops if a
 * misbehaving or malicious peer floods control frames.
 */
#define USMP_MAX_CTRL_FRAMES 8

// Helpers ───────────────────────────────────────────────────────────────────

static void build_aad(uint16_t magic, uint8_t version, uint8_t type, uint32_t seq, uint16_t length,
                      uint8_t* aad) {
  aad[0] = magic & 0xFF;
  aad[1] = (magic >> 8) & 0xFF;
  aad[2] = version;
  aad[3] = type;
  aad[4] = seq & 0xFF;
  aad[5] = (seq >> 8) & 0xFF;
  aad[6] = (seq >> 16) & 0xFF;
  aad[7] = (seq >> 24) & 0xFF;
  aad[8] = length & 0xFF;
  aad[9] = (length >> 8) & 0xFF;
}

// Send an encrypted control frame (PING, PONG, BYE) with empty plaintext ───
static int send_control(usmp_t* ctx, uint8_t type) {
  usmp_packet_t pkt;
  memset(&pkt, 0, sizeof(pkt));
  pkt.magic = USMP_MAGIC;
  pkt.version = 1;
  pkt.type = type;
  pkt.seq = ctx->tx_seq;

  /*
   * Encrypted payload for a control frame is just the AES-GCM output for
   * empty plaintext: nonce(12) || tag(16) = 28 bytes total.
   */
  uint16_t enc_length = 12 + USMP_GCM_TAG_LEN;  // nonce + tag, empty plaintext
  uint8_t aad[10];
  build_aad(pkt.magic, pkt.version, pkt.type, pkt.seq, enc_length, aad);

  uint8_t nonce[USMP_GCM_NONCE_LEN];
  nonce[0] = pkt.seq & 0xFF;
  nonce[1] = (pkt.seq >> 8) & 0xFF;
  nonce[2] = (pkt.seq >> 16) & 0xFF;
  nonce[3] = (pkt.seq >> 24) & 0xFF;
  memcpy(nonce + 4, ctx->session_id, 8);

  size_t out_len = 0;
  if (usmp_gcm_encrypt(ctx->session_key, nonce, aad, sizeof(aad), NULL, 0, pkt.payload, &out_len) !=
      0)
    return -1;

  pkt.length = (uint16_t)out_len;

  uint8_t tx_buf[USMP_HEADER_SIZE + USMP_MAX_PAYLOAD];
  uint16_t tx_len = 0;
  usmp_build_packet(&pkt, tx_buf, &tx_len);

  if (ctx->transport.send(&ctx->transport, tx_buf, tx_len) < 0) return -1;

  ctx->tx_seq++;
  ctx->last_tx_ms = usmp_port_millis();
  return 0;
}

// Public API ────────────────────────────────────────────────────────────────

int usmp_send(usmp_t* ctx, const uint8_t* data, uint16_t len) {
  if (!ctx || !ctx->established) return -1;

  if (ctx->tx_seq >= 0xFFFFFFFF) {
    USMP_LOGE(TAG, "TX sequence overflowed");
    ctx->established = false;
    return -1;
  }

  if (len > USMP_MAX_DATA_LEN * USMP_MAX_FRAMES) {
    USMP_LOGE(TAG, "Payload too large for fragmentation limits");
    return -1;
  }

  uint16_t offset = 0;
  char _msg[64];

  while (offset < len || len == 0) {
    uint16_t chunk_len = len - offset;
    if (chunk_len > USMP_MAX_DATA_LEN) {
      chunk_len = USMP_MAX_DATA_LEN;
    }

    usmp_packet_t pkt;
    memset(&pkt, 0, sizeof(pkt));

    pkt.magic = USMP_MAGIC;
    pkt.version = 1;
    pkt.type = (offset + chunk_len < len) ? USMP_TYPE_DATA_FRAG : USMP_TYPE_DATA;
    pkt.seq = ctx->tx_seq;

    uint16_t enc_length = 12 + chunk_len + USMP_GCM_TAG_LEN;
    uint8_t aad[10];
    build_aad(pkt.magic, pkt.version, pkt.type, pkt.seq, enc_length, aad);

    uint8_t nonce[USMP_GCM_NONCE_LEN];
    nonce[0] = pkt.seq & 0xFF;
    nonce[1] = (pkt.seq >> 8) & 0xFF;
    nonce[2] = (pkt.seq >> 16) & 0xFF;
    nonce[3] = (pkt.seq >> 24) & 0xFF;
    memcpy(nonce + 4, ctx->session_id, 8);

    size_t out_len = 0;
    if (usmp_gcm_encrypt(ctx->session_key, nonce, aad, sizeof(aad), data + offset, chunk_len,
                         pkt.payload, &out_len) != 0) {
      USMP_LOGE(TAG, "Encryption failed");
      return -1;
    }

    pkt.length = (uint16_t)out_len;

    uint8_t tx_buf[USMP_HEADER_SIZE + USMP_MAX_PAYLOAD];
    uint16_t tx_len = 0;
    usmp_build_packet(&pkt, tx_buf, &tx_len);

    if (ctx->transport.send(&ctx->transport, tx_buf, tx_len) < 0) {
      USMP_LOGE(TAG, "Send failed");
      return -1;
    }

    snprintf(_msg, sizeof(_msg), "TX seq=%lu len=%u type=0x%02x", (unsigned long)ctx->tx_seq,
             chunk_len, pkt.type);
    USMP_LOGI(TAG, _msg);

    ctx->tx_seq++;
    offset += chunk_len;

    if (len == 0) {
      break;
    }
  }

  ctx->last_tx_ms = usmp_port_millis();
  return 0;
}

int usmp_recv(usmp_t* ctx, uint8_t* out, uint16_t max_len) {
  if (!ctx || !ctx->established) return -1;

  char _msg[64];
  uint8_t rx_buf[USMP_HEADER_SIZE + USMP_MAX_PAYLOAD];
  usmp_packet_t pkt;
  uint8_t dummy_out[32];  // large enough for nonce+tag of empty plaintext

  uint16_t bytes_written = 0;
  uint8_t frame_count = 0;

  for (int ctrl_count = 0;;) {
    int len = ctx->transport.recv(&ctx->transport, rx_buf, sizeof(rx_buf));
    if (len < 0) {
      USMP_LOGE(TAG, "Recv failed");
      ctx->established = false;
      return -1;
    }

    if (usmp_parse_packet(rx_buf, len, &pkt) != 0) {
      USMP_LOGE(TAG, "Parse failed");
      return -1;
    }

    /* Choose output buffer and max length for decryption */
    uint8_t* dec_dest = NULL;
    uint16_t dec_max = 0;

    if (pkt.type == USMP_TYPE_PONG || pkt.type == USMP_TYPE_PING || pkt.type == USMP_TYPE_BYE) {
      if (bytes_written > 0) {
        USMP_LOGE(TAG, "Protocol error: control frame during fragmentation");
        return -1;
      }
      dec_dest = dummy_out;
      dec_max = sizeof(dummy_out);
    } else if (pkt.type == USMP_TYPE_DATA || pkt.type == USMP_TYPE_DATA_FRAG) {
      dec_dest = out + bytes_written;
      if (max_len < bytes_written) {
        USMP_LOGE(TAG, "Buffer overflow sanity check failed");
        return -1;
      }
      dec_max = max_len - bytes_written;
    } else {
      snprintf(_msg, sizeof(_msg), "Unexpected type 0x%02x", pkt.type);
      USMP_LOGE(TAG, _msg);
      return -1;
    }

    /* Verify payload length is valid for AES-GCM (contains at least nonce + tag) */
    if (pkt.length < USMP_GCM_NONCE_LEN + USMP_GCM_TAG_LEN) {
      USMP_LOGE(TAG, "Payload too short");
      return -1;
    }
    uint16_t plain_len = pkt.length - USMP_GCM_NONCE_LEN - USMP_GCM_TAG_LEN;
    if (plain_len > dec_max) {
      USMP_LOGE(TAG, "Buffer too small for payload");
      return -1;
    }

    uint8_t aad[10];
    build_aad(pkt.magic, pkt.version, pkt.type, pkt.seq, pkt.length, aad);

    uint8_t expected_nonce[USMP_GCM_NONCE_LEN];
    expected_nonce[0] = pkt.seq & 0xFF;
    expected_nonce[1] = (pkt.seq >> 8) & 0xFF;
    expected_nonce[2] = (pkt.seq >> 16) & 0xFF;
    expected_nonce[3] = (pkt.seq >> 24) & 0xFF;
    memcpy(expected_nonce + 4, ctx->session_id, 8);

    size_t out_len = 0;
    if (usmp_gcm_decrypt(ctx->session_key, expected_nonce, aad, sizeof(aad), pkt.payload,
                         pkt.length, dec_dest, &out_len) != 0) {
      USMP_LOGE(TAG, "Decryption failed");
      if (ctx->transport.confirm_authenticated) {
        continue;  // UDP: drop unauthenticated packet and continue reading
      }
      return -1;
    }

    if (ctx->rx_seq >= 0xFFFFFFFF) {
      USMP_LOGE(TAG, "RX sequence overflowed");
      ctx->established = false;
      return -1;
    }

    if (pkt.seq != ctx->rx_seq) {
      snprintf(_msg, sizeof(_msg), "Seq mismatch: expected %lu got %lu", (unsigned long)ctx->rx_seq,
               (unsigned long)pkt.seq);
      USMP_LOGE(TAG, _msg);
      return -1;
    }

    ctx->rx_seq++;

    if (ctx->transport.confirm_authenticated) {
      ctx->transport.confirm_authenticated(&ctx->transport, pkt.seq);
    }

    /* Handle control frames and loop back for the next frame */
    if (pkt.type == USMP_TYPE_PONG) {
      USMP_LOGI(TAG, "PONG received");
      if (++ctrl_count >= USMP_MAX_CTRL_FRAMES) {
        USMP_LOGE(TAG, "Too many consecutive control frames — possible flood");
        return -1;
      }
      if (ctx->transport.available && ctx->transport.available(&ctx->transport) <= 0) {
        return 0;
      }
      continue;

    } else if (pkt.type == USMP_TYPE_PING) {
      USMP_LOGI(TAG, "PING received — responding with PONG");
      if (send_control(ctx, USMP_TYPE_PONG) != 0) {
        USMP_LOGE(TAG, "Failed to send PONG");
        ctx->established = false;
        return -1;
      }
      if (++ctrl_count >= USMP_MAX_CTRL_FRAMES) {
        USMP_LOGE(TAG, "Too many consecutive control frames — possible flood");
        return -1;
      }
      if (ctx->transport.available && ctx->transport.available(&ctx->transport) <= 0) {
        return 0;
      }
      continue;

    } else if (pkt.type == USMP_TYPE_BYE) {
      USMP_LOGI(TAG, "BYE received — session closed by peer");
      ctx->established = false;
      return -1;
    }

    /* It's a DATA or DATA_FRAG frame */
    bytes_written += (uint16_t)out_len;
    frame_count++;

    if (pkt.type == USMP_TYPE_DATA) {
      /* Reassembly complete */
      snprintf(_msg, sizeof(_msg), "RX total len=%u frames=%u", bytes_written, frame_count);
      USMP_LOGI(TAG, _msg);
      return bytes_written;
    }

    /* It was a DATA_FRAG frame. Verify we haven't hit the frame limit */
    if (frame_count >= USMP_MAX_FRAMES) {
      USMP_LOGE(TAG, "Protocol error: exceeded max fragments limit");
      return -1;
    }

    /* Loop back to read the next fragment immediately */
  }
}

int usmp_ping(usmp_t* ctx) {
  if (!ctx || !ctx->established) return -1;

  if (send_control(ctx, USMP_TYPE_PING) != 0) {
    USMP_LOGE(TAG, "PING send failed");
    ctx->established = false;
    return -1;
  }

  USMP_LOGI(TAG, "PING sent");
  return 0;
}

int usmp_keepalive_tick(usmp_t* ctx) {
  if (!ctx || !ctx->established) return -1;

  if (ctx->keepalive_ms == 0) return 0;  // disabled

  uint32_t now = usmp_port_millis();
  if ((now - ctx->last_tx_ms) >= ctx->keepalive_ms) return usmp_ping(ctx);

  return 0;
}
